
package GedcomException;

/**
 * Classe Mère
 */
@SuppressWarnings("serial")
public class GedcomException extends Exception {
	/**
	 * Classe Mère
	 */
    public GedcomException(String message) {
        super(message);
    }
}