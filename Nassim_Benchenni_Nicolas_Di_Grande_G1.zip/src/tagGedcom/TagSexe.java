package tagGedcom;


/**
 * Gère le Tag qui attribut un Sexe
 */
@SuppressWarnings("serial")
public class TagSexe extends Tag {
    public TagSexe(String valeur) {
        super(valeur);
    }
}
