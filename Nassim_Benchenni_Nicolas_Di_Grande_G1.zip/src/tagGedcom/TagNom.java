package tagGedcom;


/**
 * Gère le Tag qui attribut un Nom
 */
@SuppressWarnings("serial")
public class TagNom extends Tag {
    public TagNom(String valeur) {
        super(valeur); // Appelle le constructeur du parent (Tag)
    }
}